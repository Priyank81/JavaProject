/**
 * This class will define the particular category of seven seater vehicle..
 * @author (Ankush)
 * @version (Java 8)
 */

package com.h7.busPass;

public class SevenSeater extends Vehicle {

    // constructor of SevenSeater class
    public SevenSeater(String vehicleNumber) {
        this.capacity = 7;
        this.vehicleNumber = vehicleNumber;
    }
}
